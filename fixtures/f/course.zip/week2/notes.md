# Week two notes

Tissues are groups of cells.
