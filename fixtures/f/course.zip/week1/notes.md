# Week one notes

Cells are the smallest units of life. They were first described in 1665.
